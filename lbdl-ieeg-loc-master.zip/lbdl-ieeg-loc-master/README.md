# lbdl-ieeg-loc
Functions and resources for iEEG electrode localization
