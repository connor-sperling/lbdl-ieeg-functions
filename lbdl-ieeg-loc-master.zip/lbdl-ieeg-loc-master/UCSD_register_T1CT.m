function [CTreg,metam,debug] = UCSD_register_T1CT
% function UCSD_register_T1CT
% 
% Register pre-Op T1 MRI to post-op CT. This is the precursor to electrode 
% localization 
% steps:
% 1) Convert dicoms into MGZ % 20 seconds
% 2) Run freesurfer autorecon1 (includes skull-stripping & T1.mgz) % 5 minutes
% 3) Import volumes into matlab % 30 seconds
% 4) Spot check volume orientation (manual)
% 4) Run imregister % 1 hour
% 5) Save registered CT volume  % 3 seconds
% 6) Continue freesurfer reconstruction % 4.5-5 hours
%
% Burke Rosen 2018.10.18
%
% 18.10.31 added saving CTreg.mgz
%
% ToDo: 
% Don't overwrite freesurfer
% 



%% parameters
% freesurfer reconstruction directory path
subjsDir = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/rec';

% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD001/20170217/4-Ax_FSPGR_3D_HAIM/000000.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD002/20170223/SAG_FSPGR_3D/IM-0002-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD003/20170410/AX_FSPGR_PRE_REFORMAT/IM-0012-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD004/20170410/14-+C_AX_FSPGR_3D_BEN-HAIM
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD005/20170830/+C_AX_FSPGR_3D_BENHAIM/IM-0006-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD006/20171103/SAG_FSPGR_3D/IM-0002-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD007/20180106/MultiPlanar_Reconstruction_(MPR)_Ob_Sag_R__L_Average_sp094_t/IM-0004-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD008/20180330/+C_COR_FSPGR_REFORMAT/IM-0006-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD009/20180418/AX_FSPGR_3D_POST/IM-0052-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD010/20180611/AX_FSPGR_3D_POST/IM-0029-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD011/20180611/MultiPlanar_Reconstruction_MPR_Ob_Sag_R__L_Average_sp094_t/IM-0005-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD012/20180813/Ax_FSPGR_3D_post/IM-0002-0001.dcm';

% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD014/20181005/Ax_SPGR_Reformat_Post/IM-0007-0001.dcm';
% DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD015/20181009/T1_MPR_ISO_AXIAL/IM-0005-0123.dcm';
DCM.T1 = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD016';


subj = regexp(DCM.T1,'/','split');
subj = subj{end-3};


% DCM.CT = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD006/20171106/25mm_Standard/IM-0030-0001.dcm';


% DCM.CT = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD009/20180514/Axial_CT_of_Head/IM-0065-0001.dcm';
% DCM.CT = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD010/20180611/Axial_CT_of_Head/IM-0047-0001.dcm';
% DCM.CT = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/UCSD015/20181023/coronal_head/IM-0015-0001.dcm';
DCM.CT = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/img/SD016';








%%% archival

% DCM.T1 = '../img/SD012/20180717/AX_T1_SE_+C_NON_FS/IM-0022-0001.dcm'

% DCM.T1 = '../img/SD013/20160301/AX_T1_SE_1NEX/IM-0005-0001.dcm' #bad
%  DCM.T1 = '../img/SD013/20160301/AX_REFORMATE/IM-0015-0511.dcm'

% raw data dicoms
% DCM.T1 = ...
%  '~ekaestne/Documents/SD011/20180611/AX_FSPGR_3D_POST/IM-0004-0001.dcm';
% DCM.CT = ...
%   ' /home/ekaestne/Documents/SD011/20180618/Axial_CT_of_Head/IM-0023-0001.dcm';

% DCM.T1 = ...
%  '~ekaestne/Documents/SD010/20180611/AX_FSPGR_3D_POST/IM-0029-0001.dcm';


% DCM.T1 = ...
% '~ekaestne/Documents/SD009/20180418/AX_FSPGR_3D_POST/IM-0052-0001.dcm';
% DCM.CT = ...
%   '/home/ekaestne/Documents/SD009/20180514/Axial_CT_of_Head/IM-0065-0001.dcm';

% 
% DCM.T1 = ...
% '~ekaestne/Documents/UCSD015/20181009/T1_MPR_ISO_AXIAL/IM-0005-0123.dcm';
% DCM.CT = ...
%   '~ekaestne/Documents/UCSD015/20181023/5mm_Std/IM-0014-0001.dcm';


%   '~ekaestne/Documents/UCSD015/20181023/Copilot_Coronal_MPR__NOT_FOR_CLINICAL_USE/IM-0019-0001.dcm'
%    '~ekaestne/Documents/UCSD015/20181023/25mm_Bone/IM-0013-0001.dcm';
   
  
% DCM.CT = ...
%    '~ekaestne/Documents/UCSD015/20181023/coronal_head/IM-0015-0001.dcm';


% DCM.T1 = ...
%   '''/space/seh8/3/halgdev/projects/xjiang4/UCSD_scans/SD04/MRI_exported_DICOM/LP001_20170410-LP001_20170410/LP001_20170410-MRI BRAIN WO/W CONTRAST/3-FSPGR 3D MEG/000000.dcm''';
% DCM.CT = ...
%   '''/space/seh8/3/halgdev/projects/xjiang4/UCSD_scans/SD04/LP001_CT_final/20170814/Coronal_Head/IM-0006-0001.dcm''';

% hopefully these work everytime
useGPU    = false; % use GPU for freesurfer? only on dh18, probably not woth it, especially with v6.0
orietDims = [1 2 3];% permutation vector for setting orientation
MaxIters  = 80e3;%10e3;% imregister iterations
slice     = 120; % slice number for spot checks
 

%% check and gather dependencies
if ~license('test','image_toolbox')
  error('imaging processing toolbox required.')
end

[s,out] = unix('echo $FREESURFER_HOME');
if s
  error('Freesurfer required.')
end
if ~strcmp(out(end-3:end-1),'600')
  warning('tested on freesurfer v6.0')
end


if isempty(which('load_mgh'))
  fprintf('Adding freesurfer matlab toolbox ... \n')
  addpath(sprintf('%s/matlab',out(1:end-1)))
end
debug = cell(5,1);%preallocate debug output;

%% convert T1 & CT dicom to mgz 
% make FS directory
cmd = sprintf('mkdir -p %s/%s/mri/orig',subjsDir,subj);
[~,~] = unix(cmd);

% convert orig T1 dicom to MGZ for Freesurfer starting point
if ~exist(sprintf('%s/%s/mri/orig/001.mgz',subjsDir,subj),'file') 
  cmd = sprintf('setenv SUBJECTS_DIR %s;mri_convert -it dicom -ot mgz "%s" %s/%s/mri/orig/001.mgz',subjsDir,DCM.T1,subjsDir,subj);
  [~,debug{1}] = unix(cmd);
end


% convert CT to conforming MGZ
% cmd = sprintf('setenv SUBJECTS_DIR %s;',subjsDir);
% cmd = sprintf('%s mri_convert -c -it dicom -ot mgz',cmd);% conform to 1mm voxel size 
%                                                                   % in coronal slice direction
% cmd = sprintf('%s -r %i %i %i',cmd,orietDims(1),orietDims(2),orietDims(3));% set CT orientation
% cmd = sprintf('%s  %s %s/%s/mri/orig/CTconform.mgz',cmd,DCM.CT,subjsDir,subj);
% [~,debug{2}] = unix(cmd);


%% run freesurfer autorecon1
% cmd = sprintf('setenv SUBJECTS_DIR %s;recon-all -use-gpu -autorecon1 -subjid %s',...-use-gpu
%   subjsDir,subj);

T1fil = sprintf('%s/%s/mri/T1.mgz',subjsDir,subj);
if ~exist(T1fil,'file')
  cmd = sprintf('setenv SUBJECTS_DIR %s;',subjsDir);
  cmd = sprintf('%s recon-all -autorecon1',cmd);
  if useGPU 
    cmd = sprintf('%s -use-gpu',cmd);
  else
    cmd = sprintf('%s -parallel -openmp `nproc`',cmd);
  end
  cmd = sprintf('%s -subjid %s',cmd,subj);
  [~,debug{3}] = unix(cmd);
end




%% import volumes into matlab
% [T1,M0] = load_mgh(sprintf('%s/%s/mri/T1.mgz',subjsDir,subj));
% CT = load_mgh(sprintf('%s/%s/mri/orig/CTconform.mgz',subjsDir,subj));




[CT,info1] = dicom23D(fileparts(DCM.CT));
[T1,info2] = dicom23D(fileparts(DCM.T1));



% auto-align orientation based on dicom info
info1 = dicominfo(DCM.CT,'UseDictionaryVR',true);
info2 = dicominfo(DCM.T1,'UseDictionaryVR',true);
[M,Rot] = GetTransformMatrix(info1, info2);

tform = affine3d(M');
% CT = imwarp(CT,tform);
[CT,~] = imwarp(CT,tform,'Interp','cubic','FillValues',0);
% save_mgh(CT,sprintf('%s/%s/mri/orig/CTconformRot.mgz',subjsDir,subj),M0);







%% spot check orientation
isGood = 'n';
CTtmp = CT;
while ~strcmp(isGood,'y')
  figure(1);clf;
  subplot(1,3,1)
  imshowpair(CTtmp(:,:,slice),T1(:,:,slice))
  subplot(1,3,2)
%   imshowpair(squeeze(CTtmp(:,slice,:)),squeeze(T1(:,slice,:)))
  subplot(1,3,3)
%   imshowpair(squeeze(CTtmp(slice,:,:)),squeeze(T1(slice,:,:)))
  tH = suptitle('check orientation')
  tH.Color = 'w';
  
  isGood = input('Orientation Correct? [y,n]:','s');
  if strcmp(isGood,'n')
    permOrd = input('Orientation permuation order? [e.g. 3 2 1]:','s');
    CTtmp = permute(CTtmp,str2num(permOrd));
  end
end
close(1);
CT = CTtmp;


%% register volumes
if 0
tic
[optimizer,metric] = imregconfig('multimodal');
optimizer.MaximumIterations = MaxIters;
CTreg = imregister(CT,T1,'affine',optimizer,metric,'PyramidLevels',3);
toc
else
   %see slicer gui
end


%% spot-check registation
figure(1);clf;
subplot(1,3,1)
imshowpair(CTreg(:,:,slice),T1(:,:,slice))
subplot(1,3,2)
imshowpair(squeeze(CTreg(:,slice,:)),squeeze(T1(:,slice,:)))
subplot(1,3,3)
imshowpair(squeeze(CTreg(slice,:,:)),squeeze(T1(slice,:,:)))
set(gcf,'color','k')
tH = suptitle('post-registration')
tH.Color = 'w';

%% save registered CT
% get documentation
mfile = dbstack('-completenames');
mfile = mfile.file;
fid = fopen(mfile);
meta.mfile = fscanf(fid,'%c',Inf);
fclose(fid);
meta.date = date;

save(sprintf('%s/%s/mri/CTreg.mat',subjsDir,subj),'CTreg','meta','-v7.3','-nocompression')

% also save as MGZ
save_mgh(CTreg,sprintf('%s/%s/mri/CTreg.mgz',subjsDir,subj))

return

%% continue freesurfer reconstruction
% autorecon 2
% ~3 hours on sh159
cmd = sprintf('setenv SUBJECTS_DIR %s;',subjsDir);
% cmd = sprintf('%s recon-all -autorecon2',cmd);
cmd = sprintf('%s recon-all -autorecon2',cmd);
if useGPU 
  cmd = sprintf('%s -use-gpu',cmd);
else
  cmd = sprintf('%s -parallel -openmp `nproc`',cmd);
end
cmd = sprintf('%s -subjid %s',cmd,subj);
[~,debug{4}] = unix(cmd);

% autorecon 3
% ~1.5 hours on sh159
cmd = sprintf('setenv SUBJECTS_DIR %s;',subjsDir);
cmd = sprintf('%s recon-all -autorecon3',cmd);
if useGPU
  cmd = sprintf('%s -use-gpu',cmd);
else
  cmd = sprintf('%s -parallel -openmp `nproc`',cmd);
end
cmd = sprintf('%s -subjid %s',cmd,subj);
[~,debug{5}] = unix(cmd);


end %EOF
















