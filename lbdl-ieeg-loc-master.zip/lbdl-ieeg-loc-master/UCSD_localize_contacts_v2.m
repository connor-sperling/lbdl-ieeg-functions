function UCSD_localize_contacts_v2
% function UCSD_localize_contacts
%
% localize contacts in coregisted CT
% steps:
% 1) load volumes, including coregistered CT
% 2) automatically locate putative locations by finding local maxima in CT
% 3) group putative shafts manually
% 4) compute principle axis of each shaft to produce optimal virtual oblique slice
% 5) lauch GUI to manually select locations
%
% Note: output is saved each time the table is edited and when the slice
%       shown changes and when the shaft shown changes, but not on click or
%       with contrast changes.
%
% Burke Rosen 2018.10.21
%
% Modified 2018.10.24 % imports existing output to continue where left off
% Modified 2018.10.31 % load CTreg.mgz instead of CTreg.mat
%
%
% ToDo:
% Handle T1 MRI overlay
% Display virtual oblique slice location
% save image'screenshots'
%
% v2: support for #contacts per shaft ~= 10
%     (copied from UAB_localize_contacts.m)

%% Parameters
subj = 'SD018';

subjsDir = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/rec';
outDir = sprintf('/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/out/%s',subj);

thresh = 180; % threshold for automatic first pass putative contact locating
smoothScale = 4; % smoothing factor for visualization (minimum = 1)


% make outut directory
if ~exist(outDir,'dir')
  unix(sprintf('mkdir -p %s',outDir));
end

outFil = sprintf('%s/%s_elecLoc.mat',outDir,subj);

%% gather dependencies
if isempty(which('fs_load_mgh'))
  addpath('/home/pubsw/packages/MMPS/MMPS_240/matlab/fsurf_tools/')
end


%% import volumes
T1 = fs_load_mgh(sprintf('%s/%s/mri/T1.mgz',subjsDir,subj));
BM = fs_load_mgh(sprintf('%s/%s/mri/brainmask.mgz',subjsDir,subj));
CT = fs_load_mgh(sprintf('%s/%s/mri/CTreg.mgz',subjsDir,subj));
% mobj = matfile(sprintf('%s/%s/mri/CTreg.mat',subjsDir,subj));
% CT = mobj.CTreg;

%% get first-pass putative contact locations
% apply skull-striping to CT   
SS = CT;
SS(find(~BM)) = NaN; %#ok<FNDSB>


%%%  thresholded centroids  method
% % % smooth volume
% % SS = smooth3(SS,'gaussian',3,.1);% smooth3(SS,'gaussian',5,.1);
% % 
% % %%% threshold and find centroids
% % thresh = 150;
% % BW = SS > thresh;
% % L = bwlabeln(logical(BW)); % label connected components in binary image
% % cen = regionprops(L,'Centroid'); % locate centers of voxel clumps
% % pCRS = vertcat(cen.Centroid);
% % 
% % figure(3);clf;
% % pH = scatter3(pCRS(:,1),pCRS(:,2),pCRS(:,3),...
% %      [],repmat([1 0 0],size(pCRS,1),1));

%%% binned regional maxima method
% smooth volume
SS = smooth3(SS,'gaussian',5,.25);% smooth3(SS,'gaussian',5,.1);

% bin to 10%iles, find regional maxima, and accept maxima >= 70th %ile
[N,EDGES,SS] = histcounts(SS,10);
cen = imregionalmax(SS,6);
cenidx = find(cen);
cenamp = SS(cenidx);
cenmask = cenamp >  6;%7
cenidx = cenidx(cenmask);
[C,R,S] = ind2sub(size(cen),cenidx);
pCRS = [C,R,S];% scanner CRS

% figure(4);clf;
% pH = scatter3(pCRS(:,1),pCRS(:,2),pCRS(:,3),...
%      [],repmat([1 0 0],size(pCRS,1),1));
% %    

%% group leads manually
if exist(outFil,'file')
  load(outFil,'eid');
else
  figure(2);clf;
  pH = scatter3(pCRS(:,1),pCRS(:,2),pCRS(:,3),[],repmat([1 0 0],size(pCRS,1),1));
  % use brush tool to group leads
  str = 'n';
  idx = 0;
  eid = zeros(size(pCRS,1),1,'int8');
  while ~strcmp(str,'y')
    idx = idx+1;
    str = input(sprintf('(%i)finished?[y/*]',idx-1),'s');
    msk = logical(get(pH,'BrushData'));
    eid(msk) = idx;
    pH.CData(msk,:,:) = 1;
  end
end

figure(2);clf;
hold on;
pH = plot3(pCRS(:,1),pCRS(:,2),pCRS(:,3),'r.','markersize',20);
text(pCRS(:,1),pCRS(:,2),pCRS(:,3),cellstr(num2str(eid)))
% str = input('good?[y/*]','s');
close(2);

pCRS = pCRS(:,[2 1 3]);

%% remove empty shafts
eN = max(eid);
ie = eN;
while ie > 0
  emsk = eid == ie;
  if all(~emsk)
    eid(eid>ie) = eid(eid>ie)-1;
    ie = max(eid) + 1;
  end
  ie = ie - 1;
end

%% principal-axis analysis
fprintf('Performing principal-axis analysis ...\n')
pAxFil = sprintf('%s/%s_EpAx.mat',outDir,subj);
if 1%~exist(pAxFil,'file') % calculating is faster than loading
  EpAx = struct();
  eN = max(eid);
  for ie = eN:-1:1;
    emsk = eid == ie;
    EpAx(ie).lco = pCRS(emsk,:);
    [~,~,V] = svd(cov(EpAx(ie).lco)); % get principal vector
    if V(1,1) ~= 0 
      M = rotationVectorToMatrix(V(:,1)./V(1,1));
    else
      M = rotationVectorToMatrix(V(:,1));% edge case where all points are in same x-slice ?
      warning(sprintf('Shaft %i hase zero variance in dimension 1, keep an eye on it ... ',ie)); 
    end
    T = [[M [0;0;0]];[0 0 0 1]];

    %rotate images
    EpAx(ie).T = affine3d(T);
    [EpAx(ie).w.CT,EpAx(ie).RB] = imwarp(CT,EpAx(ie).T);%CT_reg;
    EpAx(ie).w.T1 = imwarp(T1,EpAx(ie).T);

    % rotate points
    EpAx(ie).wlco = transformPointsForward(EpAx(ie).T,EpAx(ie).lco);
    EpAx(ie).wlco(:,1) = EpAx(ie).wlco(:,1) - EpAx(ie).RB.XWorldLimits(1)+1;
    EpAx(ie).wlco(:,2) = EpAx(ie).wlco(:,2) - EpAx(ie).RB.YWorldLimits(1)+1;
    EpAx(ie).wlco(:,3) = EpAx(ie).wlco(:,3) - EpAx(ie).RB.ZWorldLimits(1)+1;

    EpAx(ie).mu = round(mean(EpAx(ie).wlco));
    EpAx(ie).m3 = EpAx(ie).mu(3);
    [~,EpAx(ie).minv] = min(var(EpAx(ie).wlco));
  end
  save(pAxFil,'EpAx','-v7.3','-nocompression')
else
  load(pAxFil,'EpAx')
end
fprintf('Done \n')

 %%
 
 %% initialize GUI
 % store data in figure clc;
 close(get(0,'children'));
 fH = figure(1);clf; 
 fH.Position = [-1121 14 1103 973];

 % across patient data
 fH.UserData.eid = eid;
 fH.UserData.pAx = EpAx;
 fH.UserData.scale = smoothScale;% visual smoothing factor
 fH.UserData.ie = 1;

 % per-Shaft data
 fH.UserData.shaftLab = arrayfun(@(x) sprintf('shaft_%i',x),1:eN,'uni',0);
 fH.UserData.CRS = repmat({zeros(10,3)},eN,1);
 fH.UserData.tblDat = repmat({false(10,1)},eN,1);
 fH.UserData.pltXYZ = repmat({zeros(10,3)},eN,1);
 fH.UserData.clim = NaN(eN,2);
 
 fH.UserData.fName  = sprintf('%s/%s_elecLoc.mat',outDir,subj);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 % plug in existing data
 if exist(outFil,'file')
   mobj = matfile(outFil);
   fH.UserData.CRS  = mobj.CRS;
   fH.UserData.shaftLab  = mobj.lab;
   fH.UserData.tblDat = mobj.tblDat;
   fH.UserData.pltXYZ = mobj.pltXYZ;
 end
 
 
 % open GUI
 fprintf('Initializing GUI ...\n')
 plotIm(1);

 %%%%%%%%%%%%%%%%%%%%%%%%%% GUI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 %% Main function
 function plotIm(ie)
 
 clf;
 fH = get(gcf);
 

 fH.UserData.ie = ie;
 
% get stored variables
 fD = fH.UserData;
 pAx = fH.UserData.pAx(ie);


ims = {'T1','CT'};
scale = fD.scale;
ax = subplot(1,1,1);
for iIm = 2%1:numel(ims);
  pltim = squeeze(pAx.w.(ims{iIm})(:,:,pAx.m3));
  

  pltim = imresize(pltim,scale);
  pltim = imsharpen(pltim,'Radius',2,'Amount',scale);% sharpen to super-resolution
  iH = imagesc(pltim);
  set(gca,'ydir','normal')
  switch iIm
    case 1
      ax.Colormap = colormap('bone');
      hold on
    case 2
     colormap('jet');
     iH.AlphaData = 1;%0.8;
     hold on
  end
end

%plot detected contacts

% pH = scatter(scale*pAx.wlco(:,1),scale*pAx.wlco(:,2),'ko');
% pH.MarkerEdgeAlpha = 0.5;
p = polyfit(scale*pAx.wlco(:,1),scale*pAx.wlco(:,2),1);
f = polyval(p,scale*pAx.wlco(:,1));
line(scale*pAx(1).wlco(:,1),f,'color','k','lineWidth',1,'lineStyle',':');

% plot selected point on current slice
plotBox(fD,pAx);

%formating
set(gca,'yaxislocation','right')
axis('square')

if isnan(fH.UserData.clim(ie,1))
  caxis('auto')
%   caxis(caxis*.5)
  fD = fH.UserData; %not sure why more direct syntax didn't work
  fD.clim(ie,:) = get(gca,'clim');
  set(gcf,'UserData',fD);
else
   caxis(fH.UserData.clim(ie,:))
end

xl = scale.*[min(pAx.wlco(:,1)) max(pAx.wlco(:,1))]+[-50 50]*scale;
xlim(xl);
yl = scale.*[min(pAx.wlco(:,2)) max(pAx.wlco(:,2))]+[-50 50]*scale;
ylim(yl);
set(gca,'Units','pixels')

% GUI

% slice traversing buttons
upBut = uicontrol(1,'style','push','string','up','callback',@sliceUp,'Pos',[20 90 60 20]);
dnBut = uicontrol(1,'style','push','string','down','callback',@sliceDown,'Pos',[20 20 60 20]);
lbBut = uicontrol(1,'style','edit','string',sprintf('Slice %i',pAx.m3),'Pos',[20 50 80 20]);

% contrast adjustment buttones
CupBut = uicontrol(1,'style','push','string','ctrst up','callback',@ctrstUp,'Pos',[1010 90 80 40]);
CdnBut = uicontrol(1,'style','push','string','ctrst dn','callback',@ctrstDn,'Pos',[1010 20 80 40]);

% mouse scroll and click 
set(1,'WindowscrollWheelFcn',@sliceScroll); %scroll wheel for slice change
set(1,'WindowButtonUpFcn',@clickFun);  % click to select point

% shaft switching buttons and naming field
nextBut = uicontrol(1,'style','push','string','<- prev','callback',@prevShaft,'Pos',[420 20 80 40]);
prevBut = uicontrol(1,'style','push','string','next ->','callback',@nextShaft,'Pos',[620 20 80 40]);
lablBut = uicontrol(1,'style','edit','string',fD.shaftLab(ie),'callback',@writeLab,'Pos',[520 20 80 20]);

% contact number changing buttons
addBut = uicontrol(1,'style','push','string','+ con.','callback',@addCon,'Pos',[105 200 60 40]);
subBut = uicontrol(1,'style','push','string','- con.','callback',@subCon,'Pos',[105 150 60 40]);

% within shaft progress table
tbl = uitable(1,'data',fD.tblDat{ie},...
  'ColumnEditable',true,'ColumnWidth',...
  repmat({30},1,size(fD.tblDat{ie},1)),...
  'pos',[20 150 80 250],'CellEditCallback',@TableEdit);

% save outputs to disk
fH = get(gcf);
lab = fH.UserData.shaftLab;
CRS = fH.UserData.CRS;
tblDat = fH.UserData.tblDat;
pltXYZ = fH.UserData.pltXYZ;

% get documentation
mfile = dbstack('-completenames');
mfile = mfile.file;
fid = fopen(mfile);
meta.mfile = fscanf(fid,'%c',Inf);
fclose(fid);
meta.date = date;

save(fH.UserData.fName,'meta','lab','CRS','tblDat','pltXYZ','eid','-v7.3');
end %PlotIm
 
%% subfunctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function subCon(src,eve)
  ie = src.Parent.UserData.ie;
  src.Parent.UserData.CRS{ie}    = src.Parent.UserData.CRS{ie}   (1:end-1,:);
  src.Parent.UserData.tblDat{ie} = src.Parent.UserData.tblDat{ie}(1:end-1,:);
  src.Parent.UserData.pltXYZ{ie} = src.Parent.UserData.pltXYZ{ie}(1:end-1,:);
  plotIm(ie)
end
function addCon(src,eve)
  ie = src.Parent.UserData.ie;
  src.Parent.UserData.CRS{ie} = [src.Parent.UserData.CRS{ie};zeros(1,3)];
  src.Parent.UserData.tblDat{ie} = [src.Parent.UserData.tblDat{ie};false];
  src.Parent.UserData.pltXYZ{ie} = [src.Parent.UserData.pltXYZ{ie};zeros(1,3)];
  plotIm(ie)
end

function clickFun(src,eve)
  ie =  src.UserData.ie;
  pAx = src.UserData.pAx(ie);
  Cidx = find(~src.Children(1).Data,1,'first');

  if isempty(Cidx)
    return
  end

  % get coords in plot space
  src.Units = 'Pixels';
  clickXYZ = get(gca,'CurrentPoint');
  clickXYZ = clickXYZ(1,1:2)+[-1 1];
  clickXYZ = [clickXYZ pAx.m3];
  
    src.UserData.pltXYZ{ie}(Cidx,1:3) = clickXYZ;% ploting coords 
  clickXYZ = clickXYZ ./ ...
   [src.UserData.scale src.UserData.scale 1];% warped coords
 
 % convert axis coords to CRS
  clickXYZ = clickXYZ + ...
   [pAx.RB.XWorldLimits(1)+1 ...
    pAx.RB.YWorldLimits(1)+1 ...
    pAx.RB.ZWorldLimits(1)+1]; 
  clickXYZ = ...
   transformPointsInverse(pAx.T,clickXYZ);
  src.UserData.CRS{ie}(Cidx,1:3) = clickXYZ;
  if Cidx <= numel(src.Children(1).Data)
    src.UserData.tblDat{ie}(Cidx) = true;
    src.Children(1).Data(Cidx) = true;
  end  
  
  plotBox(src.UserData,pAx);
end 
function ctrstUp(src,eve)
  caxis(caxis * 0.9);
  fD = get(gcf,'UserData'); %not sure why more direct syntax didn't work
  fD.clim(fD.ie,:) = get(gca,'clim');
  set(gcf,'UserData',fD);
end

function ctrstDn(src,eve)
  caxis(caxis * 1.1);
  fD = get(gcf,'UserData'); %not sure why more direct syntax didn't work
  fD.clim(fD.ie,:) = get(gca,'clim');
  set(gcf,'UserData',fD);
end

function writeLab(src,eve)
  src.Parent.UserData.shaftLab(src.Parent.UserData.ie) = src.String;
end

function prevShaft(src,eve)
  ie = max(src.Parent.UserData.ie - 1,1);
  src.Parent.UserData.ie = ie; 
  plotIm(ie);
end

function nextShaft(src,eve)
  ie = min(src.Parent.UserData.ie + 1,...
    numel(src.Parent.UserData.pAx));
  src.Parent.UserData.ie = ie; 
  plotIm(ie);
end

function sliceUp(src,eve)
  ie =  src.Parent.UserData.ie;
  src.Parent.UserData.pAx(ie).m3 = ...
    src.Parent.UserData.pAx(ie).m3 + 1;
  plotIm(ie)
end

function sliceDown(src,eve)
  ie =  src.Parent.UserData.ie;
  src.Parent.UserData.pAx(ie).m3 = ...
    src.Parent.UserData.pAx(ie).m3 - 1;
  plotIm(ie)
end

function sliceScroll(src,eve)
  switch eve.VerticalScrollCount;
    case -1
      ie =  src.UserData.ie;
      src.UserData.pAx(ie).m3 = ...
        src.UserData.pAx(ie).m3 + 1;
      plotIm(ie)
    case 1
      ie =  src.UserData.ie;
      src.UserData.pAx(ie).m3 = ...
        src.UserData.pAx(ie).m3 - 1;
      plotIm(ie)
  end
end

function TableEdit(src,eve)
  ie = src.Parent.UserData.ie;
  src.Parent.UserData.tblDat{ie} = src.Data;
  src.Parent.UserData.pltXYZ{ie}(~src.Parent.UserData.tblDat{ie},:) = 0;
  plotIm(ie)
end

function plotBox(fD,pAx)
  delete(findobj(gcf,'type','text'))
  ie = fD.ie;
  inSlice = fD.pltXYZ{ie}(:,3) == pAx.m3;
  if any(inSlice)
    pH = scatter(fD.pltXYZ{ie}(inSlice,1),fD.pltXYZ{ie}(inSlice,2),130,'ws');
    pH.LineWidth = 2;
    if inSlice(end)
      txtStr = ([repmat('  ',sum(inSlice),1) num2str(find(inSlice))]);
    else
      txtStr = ([repmat('   ',sum(inSlice),1) num2str(find(inSlice))]);
    end
    tH = text(fD.pltXYZ{ie}(inSlice,1),fD.pltXYZ{ie}(inSlice,2),...
       txtStr,'Color',[.5 .5 .5]);
  end
end


end %EOF