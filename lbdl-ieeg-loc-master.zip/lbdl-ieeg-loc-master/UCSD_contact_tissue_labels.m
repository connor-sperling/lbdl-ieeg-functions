%%function UCSD_contact_tissue_labels

%% parameters
subj = 'SD017';
subjsDir = '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/rec';
outDir = sprintf('/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/out/%s',subj);

%% gather dependencies
if isempty(which('fs_load_mgh'))
  addpath('/home/pubsw/packages/MMPS/MMPS_240/matlab/fsurf_tools/')
end

%% load contact CRS
outFil = sprintf('%s/%s_elecLoc.mat',outDir,subj);
load(outFil,'CRS')


%% get freesurfer label key
[s,keyFil] = unix('echo $FREESURFER_HOME');
keyFil = [keyFil(1:end-1) '/FreeSurferColorLUT.txt'];
[~,nL] = unix(sprintf('wc -l %s',keyFil));
nL = regexp(nL,' ','split');
nL = str2double(nL{1});
fid = fopen(keyFil);
key = cell(nL,1);
iL = 0;
while ~feof(fid)
  iL = iL + 1;
  key{iL} = fgetl(fid);
end
key = key(~cellfun(@isempty,key));
key = key(~startsWith(key,'#'));
key = cellfun(@(x) regexp(x,' ','split'),key,'uni',0);
key = cellfun(@(x)  x(~cellfun(@isempty,x)),key,'uni',0);
keyNum = cellfun(@(x) str2double(x{1}),key);
keyStr = cellfun(@(x) x{2},key,'uni',0);

%% load segmentation and parcelation
vols = {'aparc+aseg','aparc.DKTatlas+aseg','aparc.a2009s+aseg'};
nV = numel(vols);
% Deskian/Killiany, DKT, Destrieux
for iVol = nV:-1:1
  volFil = sprintf('%s/%s/mri/%s.mgz',subjsDir,subj,vols{iVol});%Deskian/Killiany Atlas
  vol{iVol} = fs_load_mgh(volFil);
end

%% assign label to coordinates
lab = repmat({cell(10,nV)},numel(CRS),1);
for iE = 1:numel(CRS)
  rCRS = round(CRS{iE}-1);
  for iC = 1:size(rCRS,1)
    for iVol = nV:-1:1
    cIdx = vol{iVol}(rCRS(iC,1),rCRS(iC,2),rCRS(iC,3));
    lab{iE}(iC,iVol) = keyStr(keyNum == cIdx);
    end
  end
end

%% get CRS to RAS transform
h = {'lh','rh'};
for ih = 1:2
    srfP.(h{ih}) = fs_read_surf(sprintf('%s/%s/surf/%s.pial',subjsDir,subj,h{ih}));
  srf.(h{ih}) = fs_read_surf(sprintf('%s/%s/surf/%s.white',subjsDir,subj,h{ih}));
end
cmd = sprintf('mri_info --vox2ras-tkr %s/%s/mri/T1.mgz',subjsDir,subj);
[s,Torig] = unix(cmd);
Torig = str2num(Torig); %#ok<ST2NM>
Torig = Torig*[1 0 0 -1; 0 1 0 -1; 0 0 1 -1; 0 0 0 1]; % Convert to 1 indexed for matlab

%% debug 

% % ind = find(vol{3} == 12170);%frontal pole
% ind = find(vol{1} == 49);%superiortemporal
% [C,R,S] = ind2sub(size(vol{1}),ind);
% dbCRS = [C,R,S] ;
% 
% RAS = Torig*[dbCRS ones(size(dbCRS,1),1)]';
% RAS = RAS([1:3],:)';
% 
% figure(333);clf
% for ih = 1:2
%   tH = triplot(srf.(h{ih}).vertices,srf.(h{ih}).faces,1,'faces_skin');
%   tH.FaceAlpha = 0.1;
%   hold on;
% end
% view(-178,-2)
% scatter3(RAS(:,1),RAS(:,2),RAS(:,3),'og')

  %% plot
  figure(111);clf
  for ih = 1:2
  %   tH = triplot(srfP.(h{ih}).vertices,srfP.(h{ih}).faces,1,'faces_red');
  %   tH.FaceAlpha = 0.1;
    hold on
    tH = triplot(srfP.(h{ih}).vertices,srf.(h{ih}).faces,1,'faces_skin');
    tH.FaceAlpha = .9%0.7%0.7;
    hold on;
  end
  view(-178,-2)

  RAS = CRS;
  for iE = 1:numel(CRS)
  %   CRS{iE} = CRS{iE}-1;% Convert from 1-based to 0-based CRS indexing
    RAS{iE} = Torig*[CRS{iE} ones(size(CRS{iE},1),1)]';
    RAS{iE} = RAS{iE}([1:3],:)';
    RAS{iE} = RAS{iE}(:,[3 2 1]);% fix orientation
  end

  switch subj
    case 'SD017'
       shftLabs =   {'RA','RHH','RHB','RAPHG','RHT','RPPGH','RD1','RD4','RD3','RD2'};
    case 'SD016'
  %  shftLabs = {'LOF','LAC','LA','RHH','LHT','RA','RMA','LHB','LHH','LAI','LPI'}%SD016(day 4) v1
%      shftLabs =  {'LOF','LAC','LA','RHH','LHT','RA','RMA','LHB','LHH','LPI','LAI'}%SD016 (day 4)
       shftLabs =   {'ROF','RLF','RPC','RMA','RPI','RA','RHH','RHT','LOF'...
                     'LLF','LAC','LAI','LPC','LPI','LA','LHH','LHB','LHT'};%SD016 (day 18)
    case 'SD015'
      shftLabs = {'LF','LA','LHH','LHT','RHT','RAC','RFD','ROF','RFS','RHH','RA'};%SD015
    case 'SD004'
      shftLabs = {'RHT','RHH','LAC','LOF','LLF','LHH','LHT','LAL','LA'};%SD004
    otherwise
      shftLabs =  cellstr(num2str([1:numel(RAS)]'))';
  end

cmap = colormap(lines);
cmap = cmap(1:21,:);
cmap = [cmap;[1 0 1];[1 .5 1];[0 0 1]];


  for iE = 1:numel(RAS)
    hold on;
    %plot3b(RAS{iE},'.b','markersize',30);
     plot3b(RAS{iE},'.','color',cmap(iE,:),'markersize',30);
  %   text(RAS{iE}(end,1),RAS{iE}(end,2),RAS{iE}(end,3),num2str(iE))
    tH=text(RAS{iE}(end,1),RAS{iE}(end,2),RAS{iE}(end,3),shftLabs{iE});
    tH.FontSize = 18;
    tH.FontWeight = 'bold';
  end

set(findobj(gca,'type','patch'),'Facealpha',.5)
view(90,0)


return

%% pricipal-axis virtual oblique overlays
EpAxFil = sprintf('/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/out/%s/%s_EpAx.mat',subj,subj);
[~,~] = unix(sprintf(...
    'mkdir -p /space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg_pAx',subj));
load(EpAxFil,'EpAx');%20s
%%
for iE = 1:numel(EpAx) %20s per shaft
  fprintf('plotting virtual obliques for shaft %i of %i ...\n',iE,numel(EpAx))
  figure(200);clf
  set(gcf,'pos',[-2472 712 2472 653]);
  
  % load and upsample rotated volumes
  scaleFact = 4;
  clear CT T1;
  CT = imresize3(EpAx(iE).w.CT,scaleFact); % memory intensive
  T1 = imresize3(EpAx(iE).w.T1,scaleFact);
  sz = size(EpAx(iE).w.CT);
  
  Eslice = round(mean(EpAx(iE).wlco))*scaleFact;% 1 to zero indexing (?)


  clear ax;

  % sagittal
  ax(1,1) = subplot(1,3,1);cla
  imagesc(squeeze(T1(Eslice(2),:,:)))
  ax(1,2) = axes('pos',ax(1,1).Position);
  im(1) = imagesc(squeeze(CT(Eslice(2),:,:)));

  line([0 sz(2)]*scaleFact,Eslice(1)*[1 1],'Color','y','linestyle',':')
  line(Eslice(3)*[1 1],[0 sz(2)]*scaleFact,'Color','y','linestyle',':')
%   text(256*scaleFact*.95,256*scaleFact*.05,'A','Color','w','FontSize',14)
%   text(256*scaleFact*.05,256*scaleFact*.05,'P','Color','w','FontSize',14)

  % axial
  ax(2,1) = subplot(1,3,2);cla
  imagesc(squeeze(T1(:,Eslice(1),:)))
  ax(2,2) = axes('pos',ax(2,1).Position);
  im(2) = imagesc(squeeze(CT(:,Eslice(1),:)));
  set(ax(2,:),'ydir','normal');
  line([0 sz(2)]*scaleFact,Eslice(2)*[1 1],'Color','y','linestyle',':')
  line(Eslice(3)*[1 1],[0 sz(2)]*scaleFact,'Color','y','linestyle',':')
%   text(256*scaleFact*.5,256*scaleFact*.05,'R','Color','w','FontSize',14)
%   text(256*scaleFact*.5,256*scaleFact*.95,'L','Color','w','FontSize',14)
%   title(sprintf('Shaft %i',iE),'color','w')
  title(shftLabs{iE},'color','w')


  % coronal
  ax(3,1) = subplot(1,3,3);cla
  imagesc(rot90(squeeze(T1(:,:,Eslice(3))),-1));
  ax(3,2) = axes('pos',ax(3,1).Position);
  im(3) = imagesc(rot90(squeeze(CT(:,:,Eslice(3))),-1));

  line([0 sz(1)]*scaleFact,Eslice(1)*[1 1],'Color','y','linestyle',':')
  line(sz(1)*scaleFact-Eslice(2)*[1 1],[0 sz(1)]*scaleFact,'Color','y','linestyle',':')
%   text(256*scaleFact*.95,256*scaleFact*.05,'R','Color','w','FontSize',14)
%   text(256*scaleFact*.05,256*scaleFact*.05,'L','Color','w','FontSize',14)

  for iax = 1:3
    ax(iax,2).Color = 'None';
    colormap(ax(iax,1),'bone');
    colormap(ax(iax,2),'winter');
    im(iax).AlphaData = im(iax).CData > prctile(im(iax).CData(:),95);
  end
  axis(ax,'square')
  set(ax,'xTickLabels','','yTickLabels','')
  drawnow;
  set(gcf,'color',[.05 .05 .05]);
  
  
  setpaper;
  fName = sprintf(...
    '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg_pAx/%s_coreg_pAx_%s.png',...
    subj,subj,shftLabs{iE});
  print(200,fName,'-dpng','-r300');
  close(200);
end
clear EpAx;

%% orthagonal T1/CT overlays
T1c = fs_load_mgh(sprintf('%s/%s/mri/T1.mgz',subjsDir,subj));
CTc = fs_load_mgh(sprintf('%s/%s/mri/CTreg.mgz',subjsDir,subj));

scaleFact = 4;% upscale images by this factor for aesthetic reasons 
CT = imresize3(CTc,scaleFact);
T1 = imresize3(T1c,scaleFact);

for iE = 1:numel(CRS)
  Eslice = round(mean(CRS{iE}-1))*scaleFact;% 1 to zero indexing (?)

  figure(200+iE);clf
  set(gcf,'pos',[-2472 712 2472 653]);
  clear ax;

  % sagittal
  ax(1,1) = subplot(1,3,1);cla
  imagesc(squeeze(T1(Eslice(2),:,:)))
  ax(1,2) = axes('pos',ax(1,1).Position);
  im(1) = imagesc(squeeze(CT(Eslice(2),:,:)));

  line([0 256]*scaleFact,Eslice(1)*[1 1],'Color','y','linestyle',':')
  line(Eslice(3)*[1 1],[0 256]*scaleFact,'Color','y','linestyle',':')
  text(256*scaleFact*.95,256*scaleFact*.05,'A','Color','w','FontSize',14)
  text(256*scaleFact*.05,256*scaleFact*.05,'P','Color','w','FontSize',14)

  % axial
  ax(2,1) = subplot(1,3,2);cla
  imagesc(squeeze(T1(:,Eslice(1),:)))
  ax(2,2) = axes('pos',ax(2,1).Position);
  im(2) = imagesc(squeeze(CT(:,Eslice(1),:)));
  set(ax(2,:),'ydir','normal');
  line([0 256]*scaleFact,Eslice(2)*[1 1],'Color','y','linestyle',':')
  line(Eslice(3)*[1 1],[0 256]*scaleFact,'Color','y','linestyle',':')
  text(256*scaleFact*.5,256*scaleFact*.05,'R','Color','w','FontSize',14)
  text(256*scaleFact*.5,256*scaleFact*.95,'L','Color','w','FontSize',14)
  title(shftLabs{iE},'color','w')

  % coronal
  ax(3,1) = subplot(1,3,3);cla
  imagesc(rot90(squeeze(T1(:,:,Eslice(3))),-1));
  ax(3,2) = axes('pos',ax(3,1).Position);
  im(3) = imagesc(rot90(squeeze(CT(:,:,Eslice(3))),-1));

  line([0 256]*scaleFact,Eslice(1)*[1 1],'Color','y','linestyle',':')
  line(256*scaleFact-Eslice(2)*[1 1],[0 256]*scaleFact,'Color','y','linestyle',':')
  text(256*scaleFact*.95,256*scaleFact*.05,'R','Color','w','FontSize',14)
  text(256*scaleFact*.05,256*scaleFact*.05,'L','Color','w','FontSize',14)

  for iax = 1:3
    ax(iax,2).Color = 'None';
    colormap(ax(iax,1),'bone');
    colormap(ax(iax,2),'winter');
    im(iax).AlphaData = im(iax).CData > prctile(im(iax).CData(:),95);
  end
  axis(ax,'square')
  set(ax,'xTickLabels','','yTickLabels','')
  drawnow;
  set(gcf,'color',[.05 .05 .05]);
  
  
  setpaper;
  [~,~] = unix(sprintf(...
    'mkdir -p /space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg',subj));
  fName = sprintf(...
    '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg/%s_coreg_%s.png',...
    subj,subj,shftLabs{iE});
  print(fName,'-dpng','-r300');
end
%%
% for iE = 1:numel(CRS)
%   setpaper;
%   [~,~] = unix(sprintf(...
%     'mkdir -p /space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg',subj));
%   fName = sprintf(...
%     '/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/coreg/%s_coreg_shaft%i.png',...
%     subj,subj,iE);
%   print(fName,'-dpng','-r300');
% end



%%
% figure(114);clf
% for iax = 1:2
%   subplot(1,2,iax)
%   cSlice = Eslice/scaleFact;
%   [X,Y,Z] = meshgrid(1:256,1:256,1:256);
%   sH = slice(X,Y,Z,T1c,cSlice(1),cSlice(2),cSlice(3));
%   set(sH,'LineStyle','none')
%   axis('square')
%   set(gca,'visible','off')
%   switch iax 
%     case 1
%       view(-80,12)
%     case 2
%       view(-70,-73)
%   end
% end




%% print csv
fName = sprintf('/space/mdeh7/1/halgdev/projects/bqrosen/UCSD/SD_SEEG_imaging_DEV/%s/%s_contact_RAS.csv',subj,subj);
fid = fopen(fName,'w+');
fprintf(fid,'label,contact,R,A,S');

for iS = 1:numel(shftLabs);
  for iC = 1:size(RAS{iS},1)
    fprintf(fid,'\n%s,%i,%.4f,%.4f,%.4f',...
      shftLabs{iS},iC,RAS{iS}(iC,1),RAS{iS}(iC,2),RAS{iS}(iC,3));
  end
end
fclose(fid);




return 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% archival code below
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% assign shaft labels

% get alpha part of channel names which occur 10 times
edfFil = '/space/seh8/3/halgdev/projects/bqrosen/MULTI_initial/seeg_UCSD/SD018/SD018_Day02.edf';
hdr = read_edf(edfFil);
shftLabs = hdr.label;
shftLabs = cellfun(@(x) x(isstrprop(x,'alpha')), shftLabs,'uni',0);
[shftLabs,~,shftIdx] = unique(shftLabs);
shftLabs = shftLabs(histcounts(shftIdx,1:numel(shftLabs)) == 10);
disp(shftLabs)



%% SD015
% 2 Right Amygdala
% 3 R Hippocampal Head
% 1 R hippocampal tail
% 11 R AC
% 10 Right frontal lesion deep
% 9 Right frontal lesion superior
% 8 Right frontal lesion new (ROF)
% 4 L Amygdala
% 5 L Hippocampal head
% 6 L hippocampal tail
% 7 L frontal

%% 
cmap = colormap(lines);
h = {'lh','rh'};
for ih = 2%1:2
  srf.(h{ih}) = fs_read_surf(sprintf('%s/%s/surf/%s.pial',subjsDir,subj,h{ih}));
end
figure(112);clf
ih = 2;
tH = triplot(srf.(h{ih}).vertices,srf.(h{ih}).faces,1,'faces_skin');
% tH.FaceAlpha = 0.1;
hold on;
view(90,0)

RAS{6}(end,:) = [42.81,34.69,35.94]; % 36.4177   34.8010   35.4534
RAS{7}(end,:) = [23.99,29.48,48.13]; % 24.8256   29.6630   53.0434

shftLabs = {'LH','LA','LHH','LHT','RHT','RAC','RFD','ROF','RFS','RHH','RA'};
for iE = 1:numel(shftLabs);
  if strcmp('R',shftLabs{iE}(1))
    if ismember(shftLabs{iE},{'ROF'})
      idx = 9
    else
      idx = 10;
    end
    pH = plot3b(RAS{iE}(idx,:),'.r');
    pH.Color = cmap(4,:);
    pH.MarkerSize = 45;
%     pH.LineWidth = 20;
    if iE == 11
      txtH = text(RAS{iE}(idx,1),RAS{iE}(idx,2),RAS{iE}(idx,3)*1.2,['   ' shftLabs{iE}]);
    else
      txtH = text(RAS{iE}(idx,1),RAS{iE}(idx,2),RAS{iE}(idx,3),['   ' shftLabs{iE}]);
    end
    txtH.FontWeight = 'Bold'
    txtH.HorizontalAlignment = 'Left';
    txtH.VerticalAlignment = 'Bottom';
    txtH.FontSize = 13
;  end
end

view(111.6,18.4)






%%
cmap = colormap(lines);
h = {'lh','rh'};
for ih = 1:2
  srf1.(h{ih}) = fs_read_surf(sprintf('%s/%s/surf/%s.pial',subjsDir,subj,h{ih}));
   srf1.(h{ih}) = fs_read_surf(sprintf('%s/%s/surf/%s.pial',subjsDir,subj,h{ih}));
end
figure(113);clf
ih = 2;
tH = triplot(srf.(h{ih}).vertices,srf.(h{ih}).faces,1,'faces_skin');
% tH.FaceAlpha = 0.1;
hold on;
view(90,0)





shftLabs = {'LH','LA','LHH','LHT','RHT','RAC','RFD','ROF','RFS','RHH','RA'};
for iE = 1:numel(shftLabs);
  if strcmp('R',shftLabs{iE}(1))
    if ismember(shftLabs{iE},{'ROF'})
      idx = 9
    else
      idx = 10;
    end
    pH = plot3b(RAS{iE}(idx,:),'.r');
    pH.Color = cmap(4,:);
    pH.MarkerSize = 45;
%     pH.LineWidth = 20;
    if iE == 11
      txtH = text(RAS{iE}(idx,1),RAS{iE}(idx,2),RAS{iE}(idx,3)*1.2,['   ' shftLabs{iE}]);
    else
      txtH = text(RAS{iE}(idx,1),RAS{iE}(idx,2),RAS{iE}(idx,3),['   ' shftLabs{iE}]);
    end
    txtH.FontWeight = 'Bold'
    txtH.HorizontalAlignment = 'Left';
    txtH.VerticalAlignment = 'Bottom';
    txtH.FontSize = 13
;  end
end




























